//
//  main.m
//  Quiz
//
//  Created by Nilay Modi on 2/21/14.
//  Copyright (c) 2014 Nilay Modi. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "BNRAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([BNRAppDelegate class]));
    }
}

//
//  BNRItemsViewController.h
//  Homepwner
//
//  Created by Nilay Modi on 2/27/14.
//  Copyright (c) 2014 Nilay Modi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BNRItemsViewController : UITableViewController <UITableViewDataSource>

@end

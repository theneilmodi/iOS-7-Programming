//
//  BNRDateViewController.h
//  Homepwner
//
//  Created by Nilay Modi on 3/2/14.
//  Copyright (c) 2014 Nilay Modi. All rights reserved.
//

#import <UIKit/UIKit.h>
@class BNRItem;

@interface BNRDateViewController : UIViewController

@property (strong, nonatomic) BNRItem *item;

@end

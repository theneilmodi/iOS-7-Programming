//
//  BNRDateViewController.m
//  Homepwner
//
//  Created by Nilay Modi on 3/2/14.
//  Copyright (c) 2014 Nilay Modi. All rights reserved.
//

#import "BNRDateViewController.h"
#import "BNRItem.h"

@interface BNRDateViewController ()

@property (weak, nonatomic) IBOutlet UIDatePicker *datePicker;

@end

@implementation BNRDateViewController

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:YES];
    
    self.datePicker.date = self.item.dateCreated;
}

-(void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:YES];
    [self.view endEditing:YES];
    
    self.item.dateCreated = self.datePicker.date;
}
@end

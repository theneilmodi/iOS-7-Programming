//
//  BNRItemsViewController.m
//  Homepwner
//
//  Created by Nilay Modi on 2/27/14.
//  Copyright (c) 2014 Nilay Modi. All rights reserved.
//

#import "BNRItemsViewController.h"
#import "BNRItem.h"
#import "BNRItemStore.h"

@implementation BNRItemsViewController

-(instancetype)init
{
    self = [super initWithStyle:UITableViewStylePlain];
    if(self){
        for (int i = 0; i<5; i++) {
            [[BNRItemStore sharedStore] createItem];
        }
    }
    return self;
}



-(instancetype)initWithStyle:(UITableViewStyle)style
{
    return [self init];
}

-(void)viewDidLoad
{
    [super viewDidLoad];
    [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"UITableViewCell"];
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    tableView.backgroundView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"background.jpg"]];
    return [[[BNRItemStore sharedStore] allItems] count]+1;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"UITableViewCell" forIndexPath:indexPath];
    
    tableView.rowHeight = 3.0;
    
    NSArray *itemList = [[BNRItemStore sharedStore] allItems];
    
    if(indexPath.row == [itemList count]){
        cell.textLabel.text = @"No more items!";
    }
    else{
        BNRItem *item = itemList[indexPath.row];
        cell.textLabel.text = [item description];
        cell.textLabel.font = [UIFont systemFontOfSize:20];
    }
    
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSArray *itemList = [[BNRItemStore sharedStore] allItems];
    
    if(indexPath.row == [itemList count]){
        return 44;
    }else return 60;
}




@end

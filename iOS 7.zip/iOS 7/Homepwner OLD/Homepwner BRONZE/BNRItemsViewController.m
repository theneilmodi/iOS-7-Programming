//
//  BNRItemsViewController.m
//  Homepwner
//
//  Created by Nilay Modi on 2/27/14.
//  Copyright (c) 2014 Nilay Modi. All rights reserved.
//

#import "BNRItemsViewController.h"
#import "BNRItem.h"
#import "BNRItemStore.h"

@implementation BNRItemsViewController

-(instancetype)init
{
    self = [super initWithStyle:UITableViewStylePlain];
    if(self){
        for (int i = 0; i<5; i++) {
            [[BNRItemStore sharedStore] createItem];
        }
    }
    return self;
}



-(instancetype)initWithStyle:(UITableViewStyle)style
{
    return [self init];
}

-(void)viewDidLoad
{
    [super viewDidLoad];
    [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"UITableViewCell"];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return [[[BNRItemStore sharedStore] allItems] count];
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{

    NSArray *allItems = [[BNRItemStore sharedStore] allItems];
    return [allItems[section] count];
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"UITableViewCell" forIndexPath:indexPath];
    
    NSArray *itemList = [[BNRItemStore sharedStore] allItems];
    BNRItem *item = itemList[indexPath.section][indexPath.row];
    
    cell.textLabel.text = [item description];
    
    if(indexPath.section == 0){
        cell.backgroundColor = [UIColor redColor];
    }else if(indexPath.section == 1){
        cell.backgroundColor = [UIColor greenColor];

    }

 
    return cell;
}




@end

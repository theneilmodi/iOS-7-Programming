//
//  BNRDrawView.h
//  TouchTracker
//
//  Created by Nilay Modi on 3/3/14.
//  Copyright (c) 2014 Nilay Modi. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BNRDrawView : UIView

@end

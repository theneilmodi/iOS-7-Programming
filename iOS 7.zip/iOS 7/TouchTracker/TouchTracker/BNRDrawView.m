//
//  BNRDrawView.m
//  TouchTracker
//
//  Created by Nilay Modi on 3/3/14.
//  Copyright (c) 2014 Nilay Modi. All rights reserved.
//

#import "BNRDrawView.h"
#import "BNRLine.h"

@interface BNRDrawView() <UIGestureRecognizerDelegate>

@property (strong,nonatomic) UIPanGestureRecognizer *moveRecognizer;

@property (strong, nonatomic) NSMutableDictionary *linesInProgress;
@property (strong, nonatomic) NSMutableArray *finishedLines;
@property (weak, nonatomic) BNRLine *selectedLine;

@end

@implementation BNRDrawView

-(instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    
    if(self){
        self.linesInProgress = [[NSMutableDictionary alloc] init];
        self.finishedLines = [[NSMutableArray alloc] init];
        self.backgroundColor = [UIColor grayColor];
        self.multipleTouchEnabled = YES;
        
        
        
        UITapGestureRecognizer *doubleTap = [[UITapGestureRecognizer alloc]
                                             initWithTarget:self action:@selector(doubleTap:)];
        doubleTap.numberOfTapsRequired = 2;
        doubleTap.delaysTouchesBegan = YES;
        [self addGestureRecognizer:doubleTap];
        
        UITapGestureRecognizer *singleTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tap:)];
        
        [singleTap requireGestureRecognizerToFail:doubleTap];
        [self addGestureRecognizer:singleTap];
        
        UILongPressGestureRecognizer *longPress = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(longPress:)];
        [self addGestureRecognizer:longPress];
        
        self.moveRecognizer = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(moveLine:)];
        self.moveRecognizer.delegate = self;
        self.moveRecognizer.cancelsTouchesInView = NO;

        [self addGestureRecognizer:self.moveRecognizer];
        
    }
    
    return self;
}

-(void)drawRect:(CGRect)rect
{

    for(BNRLine *line in self.finishedLines){
        CGFloat angle = [self getAngle:line.begin :line.end];
        
        if(angle < 90.0) [[UIColor blueColor] set];
        else if (angle > 90.0) [[UIColor orangeColor] set];
        else [[UIColor orangeColor] set];
        
        [self strokeLine:line];
    }
    
    [[UIColor redColor] set];
    for(NSValue *key in self.linesInProgress){
        BNRLine *line = self.linesInProgress[key];
        [self strokeLine:line];
    }
    
    if(self.selectedLine){
        [[UIColor greenColor] set];
        [self strokeLine:self.selectedLine];
    }
}

#pragma mark - self methods

-(void)strokeLine:(BNRLine *)line
{
    UIBezierPath *path = [UIBezierPath bezierPath];
    
    if(self.selectedLine.width && line == self.selectedLine) path.lineWidth = self.selectedLine.width;
    else path.lineWidth = 10;
    
    path.lineCapStyle = kCGLineCapRound;
    
    [path moveToPoint:line.begin];
    [path addLineToPoint:line.end];
    [path stroke];
}



-(BNRLine *)lineAtPoint:(CGPoint)p
{
    for(BNRLine *l in self.finishedLines){
        CGPoint start = l.begin;
        CGPoint end = l.end;
        
        for(float t = 0.0; t<=1.0; t+=0.05){
            float x = start.x + t * (end.x - start.x);
            float y = start.y + t * (end.y - start.y);
            
            if(hypot(x-p.x, y-p.y) < 20.0){
                return l;
            }
        }
        
    }
    return nil;
}

- (float)getAngle:(CGPoint)a :(CGPoint)b
{
    int x = a.x;
    int y = a.y;
    float dx = b.x - x;
    float dy = b.y - y;
    CGFloat radians = atan2(-dx,dy);        // in radians
    CGFloat degrees = radians * 180 / 3.14; // in degrees
    return degrees;
}

#pragma mark - Touch events

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    NSLog(@"%@", NSStringFromSelector(_cmd));
    
    [[UIMenuController sharedMenuController] setMenuVisible:NO animated:YES];
    self.selectedLine = nil;
    
    for(UITouch *touch in touches){
        CGPoint location = [touch locationInView:self];
        BNRLine *line = [[BNRLine alloc] init];
        line.begin = location;
        line.end = location;
        
        NSValue *key = [NSValue valueWithNonretainedObject:touch];
        self.linesInProgress[key] = line;
    }
    
    [self setNeedsDisplay];
}

-(void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
    
    NSLog(@"%@", NSStringFromSelector(_cmd));
    

    for(UITouch *touch in touches){
        NSValue *key = [NSValue valueWithNonretainedObject:touch];
        BNRLine *line = self.linesInProgress[key];
        line.end = [touch locationInView:self];
    }
    
    [self setNeedsDisplay];
}

-(void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
    NSLog(@"%@", NSStringFromSelector(_cmd));
    
    for(UITouch *touch in touches){
        NSValue *key = [NSValue valueWithNonretainedObject:touch];
        BNRLine *line = self.linesInProgress[key];
        [self.finishedLines addObject:line];
        [self.linesInProgress removeObjectForKey:key];
    }
    
    [self setNeedsDisplay];
}

-(void)touchesCancelled:(NSSet *)touches withEvent:(UIEvent *)event
{
    NSLog(@"%@", NSStringFromSelector(_cmd));
    
    for(UITouch *touch in touches){
       NSValue *key = [NSValue valueWithNonretainedObject:touch];
       [self.linesInProgress removeObjectForKey:key];
    }
    
    [self setNeedsDisplay];
}

#pragma mark - Gesture Recognizers

-(BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)otherGestureRecognizer
{
    NSLog(@"Delegate method called");
    if(gestureRecognizer == self.moveRecognizer){
        NSLog(@"Ready to pan");
        return YES;
    }
    return NO;
}

-(void)moveLine:(UIPanGestureRecognizer *)gr
{
    if(!self.selectedLine) return;
    
    if (gr.state == UIGestureRecognizerStateChanged) {
        NSLog(@"Moving line");
        
        CGPoint translation = [gr translationInView:self];
        
        CGPoint begin = self.selectedLine.begin;
        CGPoint end = self.selectedLine.end;
        
        begin.x += translation.x;
        begin.y += translation.y;
        
        end.x += translation.x;
        end.y += translation.y;
        
        self.selectedLine.begin = begin;
        self.selectedLine.end = end;
        
        CGPoint velocity = [self.moveRecognizer velocityInView:self];
        NSLog(@"%@", NSStringFromCGPoint(velocity));
        
        self.selectedLine.width = 30;
        
        [self setNeedsDisplay];
        [gr setTranslation:CGPointZero inView:self];
    }
}

-(void)longPress:(UILongPressGestureRecognizer *)gr
{
    NSLog(@"Long press");
    
    if(gr.state == UIGestureRecognizerStateBegan){
        CGPoint point = [gr locationInView:self];
        self.selectedLine = [self lineAtPoint:point];
        self.moveRecognizer.enabled = YES;
        
        if(self.selectedLine){
            [self.linesInProgress removeAllObjects];
        }
    }else if(gr.state == UIGestureRecognizerStateEnded){
        self.selectedLine = nil;
    }
    
    [self setNeedsDisplay];
}

-(void)doubleTap:(UITapGestureRecognizer *)gr
{
    NSLog(@"Double Tap");
    [self.linesInProgress removeAllObjects];
    [self.finishedLines removeAllObjects];
    [self setNeedsDisplay];
}

-(void)tap:(UITapGestureRecognizer *)gr
{
    NSLog(@"Single Tap");
    
    CGPoint point = [gr locationInView:self];
    self.selectedLine = [self lineAtPoint:point];
    
    if(self.selectedLine){
        
        [self becomeFirstResponder];
        
        self.moveRecognizer.enabled = NO;
        
        UIMenuController *menu = [UIMenuController sharedMenuController];
        
        UIMenuItem *delete = [[UIMenuItem alloc] initWithTitle:@"Delete" action:@selector(deleteLine:)];
        
        menu.menuItems = @[delete];
        [menu setTargetRect:CGRectMake(point.x, point.y, 2, 2) inView:self];
        [menu setMenuVisible:YES animated:YES];
        
    }else{
        [[UIMenuController sharedMenuController] setMenuVisible:NO animated:YES];
    }
    
    [self setNeedsDisplay];
}

#pragma mark - UIMenuController stuff

-(BOOL)canBecomeFirstResponder
{
    return YES;
}

-(void)deleteLine:(id)sender
{
    [self.finishedLines removeObject:self.selectedLine];
    [self setNeedsDisplay];
}



@end

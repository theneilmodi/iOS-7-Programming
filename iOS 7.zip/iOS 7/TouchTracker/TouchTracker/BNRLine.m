//
//  BNRLine.m
//  TouchTracker
//
//  Created by Nilay Modi on 3/3/14.
//  Copyright (c) 2014 Nilay Modi. All rights reserved.
//

#import "BNRLine.h"

@implementation BNRLine

@end

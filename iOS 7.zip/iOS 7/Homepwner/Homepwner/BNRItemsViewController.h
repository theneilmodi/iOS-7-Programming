//
//  BNRItemsViewController.h
//  Homepwner
//
//  Created by Nilay Modi on 6/13/14.
//  Copyright (c) 2014 Nilay Modi. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BNRDetailViewController.h"

@interface BNRItemsViewController : UITableViewController

@end

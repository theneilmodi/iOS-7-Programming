//
//  BNRAppDelegate.h
//  Homepwner
//
//  Created by Nilay Modi on 6/13/14.
//  Copyright (c) 2014 Nilay Modi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BNRAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end

//
//  BNRHypnosisView.h
//  Hypnosister
//
//  Created by Nilay Modi on 2/23/14.
//  Copyright (c) 2014 Nilay Modi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BNRHypnosisView : UIView

@end

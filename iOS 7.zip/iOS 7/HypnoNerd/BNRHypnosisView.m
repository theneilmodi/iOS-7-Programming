//
//  BNRHypnosisView.m
//  Hypnosister
//
//  Created by Nilay Modi on 2/23/14.
//  Copyright (c) 2014 Nilay Modi. All rights reserved.
//

#import "BNRHypnosisView.h"

@interface BNRHypnosisView()

@property (strong, nonatomic) UIColor *circleColor;

@end

@implementation BNRHypnosisView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        self.backgroundColor = [UIColor clearColor];
        self.circleColor = [UIColor lightGrayColor];
    }
    return self;
}


// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    CGRect bounds = self.bounds;
    CGPoint center;
    center.x = bounds.origin.x + (bounds.size.width / 2.0);
    center.y = bounds.origin.y + (bounds.size.height / 2.0);
    
    float maxRadius = hypot(bounds.size.width, bounds.size.height)/ 2.0;
    
    UIBezierPath *path = [[UIBezierPath alloc] init];
    
    for(float currentRadius = maxRadius; currentRadius > 0; currentRadius -= 20){
        
        [path moveToPoint:CGPointMake(center.x + currentRadius, center.y)];
        
        [path addArcWithCenter:center
                    radius:currentRadius
                startAngle:0.0
                  endAngle:M_PI*2.0
                 clockwise:YES];
    }
    
    path.lineWidth = 10;
    [self.circleColor setStroke];
    [path stroke];
    
    //UIImage *image = [UIImage imageNamed:@"bear.png"];
    //[image drawInRect:CGRectMake(center.x - 100, center.y - 100, 200, 200)];
    
    UISegmentedControl *segControl = [[UISegmentedControl alloc] initWithItems:@[@"Red", @"Green", @"Blue"]];
    [segControl setSelectedSegmentIndex:segControl.selectedSegmentIndex];
    segControl.frame = CGRectMake((bounds.size.width / 2.0) - 100, (bounds.size.height) - 100, 200, 25);
    [self addSubview:segControl];
    
    [segControl addTarget:self
                action:@selector(segmentTouch:)
      forControlEvents:UIControlEventValueChanged];
    segControl.momentary = YES;
}

-(IBAction)segmentTouch:(UISegmentedControl *)sender
{
    if(sender.selectedSegmentIndex == 0){
        self.circleColor = [UIColor redColor];
    }else if(sender.selectedSegmentIndex == 1){
        self.circleColor = [UIColor greenColor];
    }else if(sender.selectedSegmentIndex == 2){
        self.circleColor = [UIColor blueColor];
    }
}

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{

    
    float red = (arc4random() % 100) / 100.0;
    float green = (arc4random() % 100) / 100.0;
    float blue = (arc4random() % 100) / 100.0;
    
    UIColor *randomColor = [UIColor colorWithRed:red green:green blue:blue alpha:1.0];
    
    self.circleColor = randomColor;
    
}

-(void)setCircleColor:(UIColor *)circleColor
{
    _circleColor = circleColor;
    [self setNeedsDisplay];
}

@end
